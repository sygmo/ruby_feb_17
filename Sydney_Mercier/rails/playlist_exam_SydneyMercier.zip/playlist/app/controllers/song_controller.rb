class SongController < ApplicationController
	def index
		@songs = Song.all
		@song = Song.new
	end

	def create
		song = Song.new(params.require(:song).permit(:title, :artist))
		if !song.valid?
			@song = song;
			return render "index"
		end
		song.save

		redirect_to "/songs"
	end

	def show
		@song = Song.find_by(id: params[:id])
	end

	def update
		song = Song.find_by(id: params[:id])
		count = song[:add_count] + 1
		song.update_attributes(add_count: count)
		song.save

		# if Person.exists?(:user_id => session[:logged_in_as], :song_id => params[:id])
		# 	list = 
		List.create(user_id:session[:logged_in_as], song_id:params[:id])
		redirect_to "/songs"
	end
end
