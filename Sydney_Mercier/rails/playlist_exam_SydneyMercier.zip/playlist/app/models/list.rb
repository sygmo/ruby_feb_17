class List < ActiveRecord::Base
  after_initialize :set_defaults

  has_many :users
  has_many :songs

  def set_defaults
		self.times_added = 1 if self.new_record?
  end
end
