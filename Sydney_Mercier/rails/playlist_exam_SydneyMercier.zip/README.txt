Incomplete - ran out of time.

Links work on dashboard and songs/users can be added, but the show song and show playlist pages are incomplete.