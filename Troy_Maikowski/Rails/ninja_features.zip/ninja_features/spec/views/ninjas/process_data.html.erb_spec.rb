require 'rails_helper'

RSpec.describe "ninjas/process_data.html.erb", type: :view do
  
end
