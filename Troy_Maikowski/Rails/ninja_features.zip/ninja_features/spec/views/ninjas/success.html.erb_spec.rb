require 'rails_helper'

RSpec.describe "ninjas/success.html.erb", type: :view do
  
end
