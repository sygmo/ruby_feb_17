require 'rails_helper'

RSpec.describe NinjasController, type: :controller do

  

end
