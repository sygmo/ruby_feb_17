class UsersController < ApplicationController
  def index
  end

  def process_registration
  end
end
